-- Crear tabla de estudiantes
CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  age INT,
  grade VARCHAR(10)
);

-- Insertar un estudiante de ejemplo
INSERT INTO students (name, age, grade) 
VALUES ('Pacheco', 18, '7mo');

-- Crear tabla de personal administrativo
CREATE TABLE staff (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  enrollment VARCHAR(50) NOT NULL
);

-- Insertar un administrativo de ejemplo
INSERT INTO staff (name, enrollment) 
VALUES ('Carlos', 'ADM-001');
