# Oscar School Stack (2 BDs: academic_db + finance_db)

## Servicios
- MySQL 8.4 (docker) + Adminer (http://localhost:8080)
- Auth Service (login/register, emite JWT) [usa academic_db.users]
- Enrollments Service (GET/POST /enrollments, valida JWT) [usa academic_db]
- API Gateway (Express Gateway):
  - /api/auth/* -> auth-service
  - /api/enrollments/* -> enrollments-service

## Puertos
- Gateway:  http://localhost:8088
- Auth:     http://localhost:3001
- Enrolls:  http://localhost:3002
- Adminer:  http://localhost:8080
- MySQL:    3306

## Variables importantes
- Usa el mismo JWT_SECRET en: auth-service, enrollments-service y api-gateway.
- auth-service y enrollments-service apuntan a DB_HOST=mysql (nombre del servicio en docker).

## Levantar
