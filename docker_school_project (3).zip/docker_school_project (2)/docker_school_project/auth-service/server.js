// auth-service/server.js
const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');
const { v4: uuidv4 } = require('uuid');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Pool de conexiones MySQL
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10
});

// Healthcheck
app.get('/health', async (_req, res) => {
  try {
    const [r] = await pool.query('SELECT 1 as ok');
    res.json({ ok: true, db: r[0].ok === 1, mode: 'PLAINTEXT' });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// Registro (contraseña en texto plano)
app.post('/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'email/password requeridos' });

    const [exists] = await pool.query('SELECT id FROM users WHERE email=?', [email]);
    if (exists.length) return res.status(409).json({ error: 'Email ya registrado' });

    const public_id = uuidv4();

    const [result] = await pool.query(
      'INSERT INTO users (public_id, email, password, is_active) VALUES (?, ?, ?, 1)',
      [public_id, email, password]
    );

    const token = jwt.sign(
      { userId: result.insertId, publicId: public_id, email },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    res.status(201).json({ token });
  } catch (e) {
    console.error('[register] error:', e);
    res.status(500).json({ error: e.message });
  }
});

// Login (valida con contraseña en claro)
app.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    console.log('[login] body:', req.body);

    if (!email || !password) {
      console.log('[login] faltan credenciales');
      return res.status(400).json({ error: 'email/password requeridos' });
    }

    const [rows] = await pool.query(
      'SELECT id, public_id, email, password, is_active FROM users WHERE email=?',
      [email.trim().toLowerCase()]
    );
    console.log('[login] rows:', rows);

    if (!rows.length) {
      console.log('[login] usuario no encontrado');
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const user = rows[0];
    const ok = (password === user.password); // comparación directa

    if (!ok) {
      console.log('[login] contraseña incorrecta');
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    if (!user.is_active) {
      console.log('[login] usuario inactivo');
      return res.status(403).json({ error: 'Usuario inactivo' });
    }

    const token = jwt.sign(
      { userId: user.id, publicId: user.public_id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    console.log('[login] éxito, token generado');
    res.json({ token });
  } catch (e) {
    console.error('[login] error:', e);
    res.status(500).json({ error: e.message });
  }
});

// Arrancar servicio
const port = process.env.PORT || 3001;
app.listen(port, () => console.log('Auth service on', port, '| mode: PLAINTEXT'));
