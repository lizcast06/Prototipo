-- =========================================
-- academic_db (users, courses, enrollments, grades) + seeds
-- =========================================
CREATE DATABASE IF NOT EXISTS academic_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE academic_db;

-- USERS
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  public_id CHAR(36) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
);

-- Password de todos: 123456 (plaintext para dev/demo)
INSERT INTO users (public_id, email, password) VALUES
('1e4eaa12-85f3-4cf8-8fb0-0bfb27efc8d7','ana@example.com','123456'),
('3c4b1d6f-99e3-42ab-b33f-2c982a786123','juan@example.com','123456'),
('7f1b2a34-5678-4c9d-9abc-def012345678','maria@example.com','123456'),
('9a8b7c6d-5e4f-3a2b-1c0d-ffeeddccbbaa','carlos@example.com','123456'),
('5d2c1b0a-1122-3344-5566-778899aabbcc','luis@example.com','123456');

-- COURSES
CREATE TABLE IF NOT EXISTS courses (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(64) NOT NULL UNIQUE,
  title VARCHAR(255) NOT NULL,
  description TEXT NULL,
  start_date DATETIME NULL,
  end_date DATETIME NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO courses (code, title, description) VALUES
('CS101','Introducción a la Computación','Curso básico de programación'),
('MAT201','Cálculo II','Integrales y series infinitas'),
('HIS110','Historia Universal','Edad Media y Moderna'),
('PHY150','Física I','Mecánica clásica'),
('ENG200','Inglés Intermedio','Curso de inglés nivel medio');

-- ENROLLMENTS
CREATE TABLE IF NOT EXISTS enrollments (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  course_id INT UNSIGNED NOT NULL,
  status ENUM('PENDING','ENROLLED','DROPPED','COMPLETED') NOT NULL DEFAULT 'PENDING',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_enroll_user FOREIGN KEY (user_id) REFERENCES users(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT fk_enroll_course FOREIGN KEY (course_id) REFERENCES courses(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT uq_enroll_user_course UNIQUE (user_id, course_id)
);

INSERT INTO enrollments (user_id, course_id, status) VALUES
(1,1,'ENROLLED'),
(2,2,'ENROLLED'),
(3,3,'PENDING'),
(4,4,'DROPPED'),
(5,5,'COMPLETED');

-- GRADES
CREATE TABLE IF NOT EXISTS grades (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  enrollment_id INT UNSIGNED NOT NULL,
  grade DECIMAL(5,2) NULL,
  graded_at DATETIME NULL,
  notes VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_grades_enrollment FOREIGN KEY (enrollment_id) REFERENCES enrollments(id)
    ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO grades (enrollment_id, grade, graded_at, notes) VALUES
(1, 95.00, NOW(), 'Excelente desempeño'),
(2, 88.50, NOW(), 'Muy bien'),
(3, NULL,  NULL,  'Pendiente de evaluación'),
(4, 60.00, NOW(), 'Reprobado, curso dado de baja'),
(5, 100.00, NOW(), 'Curso completado con honores');
