-- =========================================
-- finance_db (payments, payment_items, invoices) + seeds
-- =========================================
CREATE DATABASE IF NOT EXISTS finance_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE finance_db;

-- PAYMENTS
CREATE TABLE IF NOT EXISTS payments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_public_id CHAR(36) NOT NULL,
  amount_cents INT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'MXN',
  status ENUM('CREATED','PENDING','PAID','FAILED','REFUNDED') NOT NULL DEFAULT 'CREATED',
  provider VARCHAR(64) NULL,
  provider_payment_id VARCHAR(128) NULL,
  enrollment_ref VARCHAR(64) NULL,
  description VARCHAR(255) NULL,              -- 👈 campo nuevo
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
);

-- Seeds: pagos con descripción
INSERT INTO payments (user_public_id, amount_cents, status, provider, provider_payment_id, enrollment_ref, description) VALUES
('1e4eaa12-85f3-4cf8-8fb0-0bfb27efc8d7', 50000,  'PAID',    'paypal', 'PP-001', 'ENR-1', 'Pago de colegiatura de universidad - CS101'),
('3c4b1d6f-99e3-42ab-b33f-2c982a786123', 75000,  'PENDING', 'stripe', 'ST-002', 'ENR-2', 'Pago de colegiatura de universidad - MAT201'),
('7f1b2a34-5678-4c9d-9abc-def012345678', 30000,  'FAILED',  'paypal', 'PP-003', 'ENR-3', 'Pago de colegiatura de universidad - HIS110'),
('9a8b7c6d-5e4f-3a2b-1c0d-ffeeddccbbaa', 100000, 'CREATED', 'stripe', 'ST-004', 'ENR-4', 'Pago de colegiatura de universidad - PHY150'),
('5d2c1b0a-1122-3344-5566-778899aabbcc', 45000,  'REFUNDED','paypal', 'PP-005', 'ENR-5', 'Pago de colegiatura de universidad - ENG200');

-- PAYMENT ITEMS
CREATE TABLE IF NOT EXISTS payment_items (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  payment_id BIGINT UNSIGNED NOT NULL,
  concept VARCHAR(255) NOT NULL,
  quantity INT UNSIGNED NOT NULL DEFAULT 1,
  unit_price_cents INT UNSIGNED NOT NULL,
  enrollment_ref VARCHAR(64) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_items_payment FOREIGN KEY (payment_id)
    REFERENCES payments(id) ON UPDATE CASCADE ON DELETE CASCADE
);

INSERT INTO payment_items (payment_id, concept, quantity, unit_price_cents, enrollment_ref) VALUES
(1, 'Matrícula CS101', 1, 50000,  'ENR-1'),
(2, 'Matrícula MAT201', 1, 75000, 'ENR-2'),
(3, 'Matrícula HIS110', 1, 30000, 'ENR-3'),
(4, 'Matrícula PHY150', 1, 100000,'ENR-4'),
(5, 'Matrícula ENG200', 1, 45000, 'ENR-5');

-- INVOICES
CREATE TABLE IF NOT EXISTS invoices (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  number VARCHAR(64) NOT NULL UNIQUE,
  user_public_id CHAR(36) NOT NULL,
  payment_id BIGINT UNSIGNED NULL,
  total_cents INT UNSIGNED NOT NULL,
  tax_cents INT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM('ISSUED','CANCELLED') NOT NULL DEFAULT 'ISSUED',
  issued_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  metadata JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_invoice_payment FOREIGN KEY (payment_id)
    REFERENCES payments(id) ON UPDATE SET NULL ON DELETE SET NULL
);

INSERT INTO invoices (number, user_public_id, payment_id, total_cents, tax_cents, status) VALUES
('F-0001', '1e4eaa12-85f3-4cf8-8fb0-0bfb27efc8d7', 1, 50000, 8000,  'ISSUED'),
('F-0002', '3c4b1d6f-99e3-42ab-b33f-2c982a786123', 2, 75000, 12000, 'ISSUED'),
('F-0003', '7f1b2a34-5678-4c9d-9abc-def012345678', 3, 30000, 4800,  'CANCELLED'),
('F-0004', '9a8b7c6d-5e4f-3a2b-1c0d-ffeeddccbbaa', 4, 100000,16000, 'ISSUED'),
('F-0005', '5d2c1b0a-1122-3344-5566-778899aabbcc', 5, 45000, 7200,  'ISSUED');
