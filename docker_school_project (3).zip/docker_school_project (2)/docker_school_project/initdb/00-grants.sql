-- =========================================
-- 00-grants.sql  (MySQL 8.4 compatible)
-- =========================================

-- Usuario de la aplicación (usado por auth-service y enrollments-service)
CREATE USER IF NOT EXISTS 'academic_user'@'%' IDENTIFIED BY 'supersecret';
ALTER USER 'academic_user'@'%' IDENTIFIED BY 'supersecret';

-- Otorgar permisos al usuario sobre las bases de datos
GRANT ALL PRIVILEGES ON academic_db.* TO 'academic_user'@'%';
GRANT ALL PRIVILEGES ON finance_db.*  TO 'academic_user'@'%';

-- Aplicar cambios
FLUSH PRIVILEGES;
