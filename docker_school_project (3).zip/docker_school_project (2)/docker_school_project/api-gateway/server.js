const express = require('express');
const cors = require('cors');
const { createProxyMiddleware } = require('http-proxy-middleware');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
app.use(cors());
//app.use(express.json());

const PORT = process.env.PORT || 8080;

// --- Middleware JWT central (se salta /api/auth/*) ---
function authenticateToken(req, res, next) {
  if (req.path.startsWith('/api/auth/')) return next();

  const authHeader = req.headers['authorization'];
  const token = authHeader?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Token requerido' });

  jwt.verify(token, process.env.JWT_SECRET, (err, payload) => {
    if (err) return res.status(403).json({ error: 'Token inválido' });
    req.user = payload;
    next();
  });
}

// Salud del gateway
app.get('/health', (_req, res) => res.json({ ok: true, gateway: 'up' }));

// --- Rutas proxied ---
// Auth (sin JWT)
app.use(
  '/api/auth',
  createProxyMiddleware({
    target: process.env.AUTH_SERVICE,
    changeOrigin: true,
    pathRewrite: { '^/api/auth': '' }
  })
);

// Enrollments (con JWT)
app.use(
  '/api/enrollments',
  authenticateToken,
  createProxyMiddleware({
    target: process.env.ENROLLMENTS_SERVICE,
    changeOrigin: true,
    pathRewrite: { '^/api/enrollments': '' }
  })
);

// Manejo simple de 404 del gateway
app.use((_req, res) => res.status(404).json({ error: 'Not found (gateway)' }));

// Arrancar
app.listen(PORT, () => {
  console.log(`API Gateway listening on port ${PORT}`);
});
