const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10
});

// Middleware para validar JWT
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Token requerido' });

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Token inválido' });
    req.user = user;
    next();
  });
}

// Healthcheck
app.get('/health', async (_req, res) => {
  try { 
    const [r] = await pool.query('SELECT 1 as ok'); 
    res.json({ ok:true, db:r[0].ok===1 }); 
  }
  catch(e){ 
    res.status(500).json({ ok:false, error:e.message }); 
  }
});

// Obtener inscripciones del usuario autenticado
app.get('/enrollments', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT e.id, c.code, c.title, e.status
       FROM enrollments e
       JOIN courses c ON e.course_id = c.id
       WHERE e.user_id = ?`, [req.user.userId]);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Crear nueva inscripción
app.post('/enrollments', authenticateToken, async (req, res) => {
  try {
    const { course_id } = req.body;
    if (!course_id) return res.status(400).json({ error: 'course_id requerido' });

    await pool.query(
      'INSERT INTO enrollments (user_id, course_id, status) VALUES (?, ?, "ENROLLED")',
      [req.user.userId, course_id]
    );

    res.status(201).json({ message: 'Inscripción creada' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Ya inscrito en este curso' });
    }
    res.status(500).json({ error: e.message });
  }
});

// Obtener todos los registros de la tabla payment_items
app.get('/getpayments', authenticateToken, async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT 
        id,
        concept AS descripcion,
        unit_price_cents AS monto,
        created_at AS fecha
      FROM payment_items
      ORDER BY created_at DESC
    `);

    res.json(rows);
  } catch (e) {
    console.error('Error al obtener payments:', e);
    res.status(500).json({ error: e.message });
  }
});

// Registrar un nuevo pago
app.post('/addpayment', authenticateToken, async (req, res) => {
  try {
    const { descripcion, monto } = req.body;

    if (!descripcion || !monto) {
      return res.status(400).json({ error: 'concept y amount son requeridos' });
    }

    // Inserta el registro con valores por defecto
    const [result] = await pool.query(`
      INSERT INTO payment_items (concept, quantity, unit_price_cents, created_at)
      VALUES (?, 1, ?, NOW())
    `, [descripcion, monto]);

    res.status(201).json({
      message: 'Pago registrado correctamente',
      id: result.insertId,
      descripcion,
      monto
    });

  } catch (e) {
    console.error('Error al insertar pago:', e);
    res.status(500).json({ error: e.message });
  }
});


const port = process.env.PORT || 3002;
app.listen(port, () => console.log('Enrollments service on', port));
